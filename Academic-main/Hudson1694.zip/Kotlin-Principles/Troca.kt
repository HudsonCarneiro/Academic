fun troca(){
    println("Digite o primeiro valor: ")
    var a = readLine()
    print("Digite o primeiro valor: ")
    var b = readln()
    var c = a;
    a = b;
    b = c;
    println("A: $a\nB: $b");
}
